const settings = {
  packname: 'Arslan Tech Hub Bot',
  author: '‎',
  botName: "A   T   H  Bot",
  botOwner: 'ArslanMD Official', // Your name
  ownerNumber: '923237045919', //Set your number here without + symbol, just add country code & number without any space
  giphyApiKey: 'qnl7ssQChTdPjsKta2Ax2LMaGXz303tq',
  commandMode: "👥public",
  maxStoreMessages: 20, 
  storeWriteInterval: 10000,
  description: "> ᴅᴇꜱᴄʀɪᴘᴛɪᴏɴ: ᴛʜɪꜱ ʙᴏᴛ ɪꜱ ꜰᴏʀ ᴍᴀɴᴀɢɪɴɢ ɢʀᴏᴜᴘ ᴄᴏᴍᴍᴀɴᴅꜱ ᴀɴᴅ ᴀᴜᴛᴏᴍᴀᴛɪɴɢ ᴛᴀꜱᴋꜱ.",
  caption: "𝐏𝐎𝐖𝐄𝐑𝐄𝐃 𝐁𝐘 𝐀𝐑𝐒𝐋𝐀𝐍-𝐌𝐃",
  version: "2.2.6 alpha-8",
  prefix: ".", // prefix (e.g., ., /, !, *)
  timezone: "Asia/Karachi", //put your country timeZone....leave blank if u don't know
  updateZipUrl: "https://api.github.com/Arslan-MD/Arslan-Tech-Bot/main/zip",
};

module.exports = settings;
